import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.CopyOption;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.*;
import io.ipfs.api.*;
import io.ipfs.multiaddr.MultiAddress;
import io.ipfs.multihash.Multihash;
import org.apache.commons.io.*;



public class uiDriver {
	static IPFS ipfs = new IPFS("/ip4/127.0.0.1/tcp/5001"); //global IPFS obj
	static String peerID = "Qma1BpdDSJiLNKQfKdr8g2WpfhJ3KxvUrwGkPJeqH39HgQ"; //my peer id

	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		String ui = "";
		String currentHash;
		while(!ui.equals("0")){
		System.out.println("Which of the following operations would you like to perform?");
		System.out.println("1. Upload"
				+ "\n2. Download"
				+ "\n3. Delete"
				+ "\n4. Synchronize"
				+ "\n5. Undo"
				+ "\n6. Remove All "
				+ "\n0. Exit");
		
		ui = scan.nextLine();
		try{
			
			int opt = Integer.parseInt(ui);
			
			System.out.println(opt);
			switch(opt){
				case 1:
					System.out.println("Enter the name of the file/directory you would like to add to IPFS: ");
					ui = scan.nextLine();
					
					
					
					currentHash = ipfs.name.resolve(Multihash.fromBase58(peerID));
					writeUndo(currentHash);
					upload(ui);
					//add(ui);'
					
					requestNamespace();
					break;
				case 2:
					download(ipfs.name.resolve(Multihash.fromBase58(peerID)));
					break;
				case 3:
					
					System.out.print("Enter the name of the file/directory you would like to remove from IPFS: \n./home/");
					ui = scan.nextLine();
					currentHash = ipfs.name.resolve(Multihash.fromBase58(peerID));
					writeUndo(currentHash);
					delete(ui);
					requestNamespace();
					break;
				case 4:
					currentHash = ipfs.name.resolve(Multihash.fromBase58(peerID));
					writeUndo(currentHash);
					
					sync();
					
					requestNamespace();
					break;
				case 5:
					undo();
					requestNamespace();
					break;
				case 6:
					//FileReader fr = new FileReader("home/undo.txt");
					//BufferedReader br = new BufferedReader(fr);
					
					//currentHash = br.readLine();
					cleanHomeDir(new File("./home"));
					currentHash = ipfs.name.resolve(Multihash.fromBase58(peerID));
					writeUndo(currentHash);
					sync();
					requestNamespace();
					break;
				default: 
					System.exit(1);
			
			}
			
			
		}catch(Exception e){
			System.out.println("64: "+e.toString());
		}
		}
	}
	public static void requestNamespace(){
		String[] cHArr;
		try {
			System.out.println("Resolving");
		cHArr = ipfs.name.resolve(Multihash.fromBase58(peerID)).split("/");
		System.out.println(cHArr[2]);
		ipfs.ls(Multihash.fromBase58(cHArr[2]));
		System.out.println("resolved");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void writeToHome(String fn){
		
		try{
		File f = new File(fn);
		
		
		if(f.exists()){
			
			
			if(f.isDirectory()){
				FileUtils.copyDirectory(f, new File("./home/"+fn));
			}else{
				Files.copy(f.toPath(), new File("./home/"+fn).toPath(),StandardCopyOption.REPLACE_EXISTING);
				
			}
		}
		}catch(Exception e){
			System.out.println(e.toString());
		}
	}
		
	private static void add(String ui) {
		// TODO Auto-generated method stub
		
		NamedStreamable.FileWrapper file = new NamedStreamable.FileWrapper(new File("home"));
		List<MerkleNode> addResult;
		try {
			writeToHome(ui);String currentHash = null;
			File undo = new File("home/undo.txt");
			if(!undo.createNewFile()){
			FileReader fr = new FileReader("home/undo.txt");
			BufferedReader br = new BufferedReader(fr);
			
			currentHash = br.readLine();
		
			//System.out.println(currentHash);
			
			}
		
			File f = new File(ui);
		
		
			if(f.exists()){
			
			
			if(f.isDirectory()){
				FileUtils.copyDirectory(f, new File("./home/"+ui));
			}else{
				Files.copy(f.toPath(), new File("./home/"+ui).toPath(),StandardCopyOption.REPLACE_EXISTING);
				
			}
			
		System.out.println("Current hash being written to undo file");
		writeUndo(currentHash);
		boolean flag = false;
		while(!flag){
		addResult = ipfs.add(file);
		System.out.println(addResult.size());
		for(MerkleNode mn: addResult){
			System.out.println(mn.name);
			if(mn.name.get().equals("home")){
				flag = true;
			}
		}
		
		
		for(MerkleNode mn: addResult){
			System.out.println("ipfs.io/ipfs/"+mn.hash);
		}
		}
		}
		
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void undo() {
		System.out.println("Attempting to revert last change");
		try {
			String hash = ipfs.name.resolve(Multihash.fromBase58(peerID));
			System.out.println(hash);
			String[] hs = hash.split("/ipfs/");
		
			List<MerkleNode> result =ipfs.ls(Multihash.fromBase58(hs[1]));
			
			List<MerkleNode> files = result.get(0).links;
			
			for(MerkleNode mn: files){
				if(mn.name.get().equals("undo.txt")){
					System.out.println(mn.hash);
					String undoHash = new String(ipfs.cat(mn.hash));
					System.out.println("UndoHash: "+undoHash.split("/ipfs/")[1]);
			//FileReader fr = new FileReader("home/undo.txt");
			//BufferedReader br = new BufferedReader(fr);
			
			//String undoHash = br.readLine();
					//String undoHash  = new String(ipfs.cat(mn.hash));
			//System.out.println("ipfs.io/ipfs"+undoHash);
					File file = new File("home");
					
					
					
					//writeUndo(ipfs.name.resolve(Multihash.fromBase58(peerID)));
					download(undoHash);
					
					//File newFile = new File(results.);
					
					
					String multHash = undoHash.split("/ipfs/")[1];
					//System.out.println(multHash);
					ipfs.name.publish(Multihash.fromBase58(multHash));
					
				}
			}
			//System.out.println(result.size());
			//System.out.println(r);
			System.out.println("Namespace should be updated now");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.print("\n95: ");
			e.printStackTrace();
		}
		
		
	}

	private static void download(String Hash) {
		System.out.println("Enter this command in the terminal/command prompt to download this directory:");
		System.out.println("ipfs get "+Hash.split("/ipfs/")[1]);
	}
	private static void sync(){
	
	//upload("home");
	publish();
	/*
	try {
		FileReader fr = new FileReader("home/undo.txt");
		BufferedReader br = new BufferedReader(fr);
		
		String undoHash = br.readLine();
		writeUndo(undoHash);
		
		NamedStreamable.FileWrapper file = new NamedStreamable.FileWrapper(new File("home"));
	
			
			
			List<MerkleNode> addResult;
			boolean flag = false;
			while(!flag){
			addResult = ipfs.add(file);
			System.out.println(addResult.size());
			for(MerkleNode mn: addResult){
				System.out.println(mn.name);
				if(mn.name.get().equals("home")){
					flag = true;
				}
			}
			
			for(MerkleNode mn: addResult){
				System.out.println("ipfs.io/ipfs/"+mn.hash);
			}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
	}
	
	
	private static void upload(String fn){
		//upload adds file to ipfs then publishes to ipns name
		//also writes current hash to a file to implement a rudementary undo system
		
		File fp = new File(fn);
		//Path p = cleanHomeDir(fp);
		Path home =  new File("./home").toPath();
		System.out.println(fn);
		

		try {
			
		/*	//if ipns currently not working
		//String currentHash = ipfs.name.resolve(Multihash.fromBase58(peerID));
			FileReader fr = new FileReader("home/undo.txt");
			BufferedReader br = new BufferedReader(fr);
			
			String currentHash = br.readLine();
		
			System.out.println(currentHash);
		
		*/
		
		
		File f = new File(fn);
		
		
		if(f.exists()){
			
			
			if(f.isDirectory()){
				FileUtils.copyDirectory(f, new File("./home/"+fn));
			}else{
				Files.copy(f.toPath(), new File("./home/"+fn).toPath(),StandardCopyOption.REPLACE_EXISTING);
				
			}
		String currentHash = ipfs.name.resolve(Multihash.fromBase58(peerID));
		System.out.println("Current hash being written to undo file");
		writeUndo(currentHash);
	
		
		System.out.println("Files have been copied to home dir adding home dir to ifps...");
		
		publish();
			
			
			
		}
		else{
			System.out.println(f.getAbsolutePath()+ "not found");
		}
			
		}catch(Exception e){
			
			System.out.println("180: "+e.toString());
		}
		
		
		
	}
	
	
	private static void writeUndo(String currentHash) {
		// TODO Auto-generated method stub
		File undo = new File("home/undo.txt");
		
		try {
		undo.createNewFile();
		
		
		FileWriter	fw = new FileWriter(undo);
		fw.write(currentHash);
		fw.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.toString();
		}
	}

	private static void publish() {
		// TODO Auto-generated method stub

		try{
NamedStreamable.FileWrapper file = new NamedStreamable.FileWrapper(new File("home"));
		
		List<MerkleNode> addResult = null;
		Map m = null;
		String ipfsPath = null;
	
		boolean flag = false;
		while(!flag){
		addResult = ipfs.add(file);
		//ipfs.cat(file);
		System.out.println(addResult.size());
		for(MerkleNode mn: addResult){
			System.out.println(mn.name);
			if(mn.name.get().equals("home")){
				flag = true;
			}
		}
		}
		
		//System.out.println(addResult.get(addResult.size()-1).name);
		System.out.println(addResult.get(addResult.size()-1).hash);
		m = ipfs.name.publish(addResult.get(addResult.size()-1).hash);
		System.out.println(m);
		ipfsPath = ipfs.name.resolve(Multihash.fromBase58(m.get("Name").toString())); 
			
			
		System.out.println("Your directory is now located at: "
					+ "\n ipfs.io"+ipfsPath);
		}catch(Exception e){
			System.out.println("199: "+e.toString());
		}
		
	}


	private static Path cleanHomeDir(File fp) {
		// TODO Auto-generated method stub
		
		Path p = fp.toPath();
		try {
			
			
			FileUtils.cleanDirectory(new File("./home"));
	
			p = FileSystems.getDefault().getPath("./","home");
			//Files.createDirectories(p);
			
		} catch (IOException e1) {
			System.out.println("home dir never existed *twilight zone music*");
			//should probably create the homefile here buuuuuut -
			File home = new File("home");
			try {
				home.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return p;
	}

	public static void delete(String ui){
		try {
			//String currentHash = ipfs.name.resolve(Multihash.fromBase58(peerID));
			
			FileReader fr = new FileReader("home/undo.txt");
			BufferedReader br = new BufferedReader(fr);
			
			String currentHash = br.readLine();
		
			System.out.println(currentHash);
		
			writeUndo(currentHash);
			ui = "./home/"+ui;

			File f = new File(ui);
			if(f.exists()){
			if(f.isDirectory()){
				FileUtils.deleteDirectory(f);
			}else{
			
			Files.delete(f.toPath());
			}
			
			sync();
			}
		
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
