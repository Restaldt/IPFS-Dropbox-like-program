import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;
import io.ipfs.api.*;
import io.ipfs.multihash.Multihash;

public class driver {

	public static void main(String [] args){
		IPFS ipfs = new IPFS("/ip4/127.0.0.1/tcp/5001");
		NamedStreamable.FileWrapper file = new NamedStreamable.FileWrapper(new File("examples"));
		List<MerkleNode> addResult = null;
		try {
			addResult = ipfs.add(file);
			System.out.println(addResult.size());
			System.out.println(addResult.get(addResult.size()-1).hash);
			System.out.println("\n***************************************\n");
			for(MerkleNode m: addResult){
			System.out.println(m.hash);
		
			byte[] fileContent = ipfs.cat(m.hash);

			String fc = new String(fileContent);
			System.out.println(fc);
		
			
			}
			
		} catch (Exception e) {
			
			System.out.println("All files have been printed");
		}
		System.out.println("\n***************************************\n");
		Map m;
		String n;
		try {
			m = ipfs.name.publish(addResult.get(addResult.size()-1).hash);
			System.out.println(m);
			
			n = ipfs.name.resolve(Multihash.fromBase58(m.get("Name").toString()));
			//n = m.get("Name").toString();
			System.out.println(n);
			
			String[] nArr = n.split("/");
			Multihash nHash = Multihash.fromBase58(nArr[nArr.length-1]);
			System.out.println(nHash);
			
			List<MerkleNode> mn = ipfs.ls(nHash);
			for(MerkleNode l:mn.get(0).links){
				System.out.println(l.hash);
			
			}
			//System.out.println(n);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	//System.out.println(ipfs.id("QmZ9baizJ1LpqipPMzggeSLetXWESz1ggAuF8o6dfiwo7K"));
		
		
	}
	public static void print(Object j){
		System.out.println(j.toString());
	}
	
	
	
}
